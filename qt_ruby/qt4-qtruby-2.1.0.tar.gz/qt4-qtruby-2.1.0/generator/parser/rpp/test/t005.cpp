.
#define COND 1 \
    && 0
.
#if COND
KO
#else
OK
#endif
.
