.
#define B
#define A defined B
.
#if A
OK
#else
KO
#endif
.
