.
#define M A\
  B C
.
M
.
.
.
.
