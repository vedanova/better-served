.
#define code(more) \
 int main () \
 { more \
 }
.
code(int x;
     int y)
.
.
