# define __nonnull(params) params
__nonnull((1));
#ifdef blah
#define blah2(a) ((a).)
#endif
