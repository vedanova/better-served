#define BLANK_MACRO

class BLANK_MACRO Blah
{
public:
  void BLANK_MACRO testFoo() const;

  void testMe();
};
