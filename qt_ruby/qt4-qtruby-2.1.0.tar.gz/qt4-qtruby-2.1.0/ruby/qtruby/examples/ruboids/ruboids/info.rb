#
# Copyright (c) 2001 by Jim Menard <jimm@io.com>
#
# Released under the same license as Ruby. See
# http://www.ruby-lang.org/en/LICENSE.txt.
#

VERSION_MAJOR = 0
VERSION_MINOR = 0
VERSION_TWEAK = 1
Version = "#{VERSION_MAJOR}.#{VERSION_MINOR}.#{VERSION_TWEAK}"
Copyright = 'Copyright (c) 2001 by Jim Menard <jimm@io.com>'
