SERVICE_NAME = "com.trolltech.QtDBus.PingExample"
