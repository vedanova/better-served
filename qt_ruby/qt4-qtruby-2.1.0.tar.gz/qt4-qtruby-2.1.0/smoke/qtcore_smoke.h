#ifndef QTCORE_SMOKE_H
#define QTCORE_SMOKE_H

#include <smoke.h>

// Defined in smokedata.cpp, initialized by init_qtcore_Smoke(), used by all .cpp files
extern "C" SMOKE_EXPORT Smoke* qtcore_Smoke;
extern "C" SMOKE_EXPORT void init_qtcore_Smoke();
extern "C" SMOKE_EXPORT void delete_qtcore_Smoke();

#ifndef QGLOBALSPACE_CLASS
#define QGLOBALSPACE_CLASS
class QGlobalSpace { };
#endif

#endif
