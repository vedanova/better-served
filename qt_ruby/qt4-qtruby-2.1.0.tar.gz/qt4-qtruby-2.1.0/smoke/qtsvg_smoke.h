#ifndef QTSVG_SMOKE_H
#define QTSVG_SMOKE_H

#include <smoke.h>

// Defined in smokedata.cpp, initialized by init_qtsvg_Smoke(), used by all .cpp files
extern "C" SMOKE_EXPORT Smoke* qtsvg_Smoke;
extern "C" SMOKE_EXPORT void init_qtsvg_Smoke();
extern "C" SMOKE_EXPORT void delete_qtsvg_Smoke();

#ifndef QGLOBALSPACE_CLASS
#define QGLOBALSPACE_CLASS
class QGlobalSpace { };
#endif

#endif
