#ifndef QTNETWORK_SMOKE_H
#define QTNETWORK_SMOKE_H

#include <smoke.h>

// Defined in smokedata.cpp, initialized by init_qtnetwork_Smoke(), used by all .cpp files
extern "C" SMOKE_EXPORT Smoke* qtnetwork_Smoke;
extern "C" SMOKE_EXPORT void init_qtnetwork_Smoke();
extern "C" SMOKE_EXPORT void delete_qtnetwork_Smoke();

#ifndef QGLOBALSPACE_CLASS
#define QGLOBALSPACE_CLASS
class QGlobalSpace { };
#endif

#endif
