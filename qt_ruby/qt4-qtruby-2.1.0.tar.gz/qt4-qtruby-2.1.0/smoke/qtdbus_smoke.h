#ifndef QTDBUS_SMOKE_H
#define QTDBUS_SMOKE_H

#include <smoke.h>

// Defined in smokedata.cpp, initialized by init_qtdbus_Smoke(), used by all .cpp files
extern "C" SMOKE_EXPORT Smoke* qtdbus_Smoke;
extern "C" SMOKE_EXPORT void init_qtdbus_Smoke();
extern "C" SMOKE_EXPORT void delete_qtdbus_Smoke();

#ifndef QGLOBALSPACE_CLASS
#define QGLOBALSPACE_CLASS
class QGlobalSpace { };
#endif

#endif
