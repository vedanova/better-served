#define BASE_SMOKE_BUILDING

#include <smoke.h>

Smoke::ClassMap Smoke::classMap;
Smoke::ModuleIndex Smoke::NullModuleIndex;
